-- Run this once in the Supabase SQL editor for project:
-- https://yaudakrqojqdvmqmekbs.supabase.co

-- 1. Shared counter, used for both "Number of downloads" and
--    "Number of active students" on the landing page (they show the same value).
create table if not exists public.app_stats (
  id int primary key,
  count bigint not null default 0
);

insert into public.app_stats (id, count)
values (1, 12480)
on conflict (id) do nothing;

-- Function that atomically bumps the counter. Called from the client
-- whenever someone clicks a "Get Started" / CTA button.
create or replace function public.increment_downloads()
returns bigint
language plpgsql
security definer
as $$
declare
  new_count bigint;
begin
  update public.app_stats
    set count = count + 1
    where id = 1
    returning count into new_count;
  return new_count;
end;
$$;

-- 2. Feedback submitted from the landing page feedback form.
create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text,
  message text not null,
  rating smallint not null check (rating between 1 and 5),
  created_at timestamptz not null default now()
);

-- 3. Row Level Security: allow the anon (public) key to read the stats
--    counter, call the increment function, and insert feedback — but not
--    read other people's feedback or edit/delete anything.
alter table public.app_stats enable row level security;
alter table public.feedback enable row level security;

create policy "Public can read stats" on public.app_stats
  for select using (true);

create policy "Public can submit feedback" on public.feedback
  for insert with check (true);

-- (No select policy on feedback -> anon key cannot read other users' feedback.)

grant execute on function public.increment_downloads() to anon;
