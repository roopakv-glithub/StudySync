import { createClient } from '@supabase/supabase-js'

const supabaseUrl =
  process.env.NEXT_PUBLIC_SUPABASE_URL ?? 'https://yaudakrqojqdvmqmekbs.supabase.co'

const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ??
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlhdWRha3Jxb2pxZHZtcW1la2JzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0NzQxNDEsImV4cCI6MjA5NjA1MDE0MX0.YjgjG2Od9G5EAx68fdAsvVik91kQdjcSbOT5zZ-9eGs'

// Single shared browser client. Safe to import from client components ("use client").
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

/** Row shape of the public.app_stats table (single row, id = 1). */
export interface AppStatsRow {
  id: number
  count: number
}

/** Row shape of the public.feedback table. */
export interface FeedbackRow {
  id?: string
  name: string
  email: string | null
  message: string
  rating: number
  created_at?: string
}
