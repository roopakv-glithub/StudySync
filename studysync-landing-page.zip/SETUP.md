# StudySync landing page — setup

## 1. Install & run
```
pnpm install   # or npm install
pnpm dev       # or npm run dev
```

## 2. Supabase
The Supabase URL + anon key are already wired into `lib/supabase.ts` and
`.env.local`. Before the stats counter / feedback form will work, run the SQL
in `supabase/schema.sql` once in your Supabase project's SQL editor
(Table Editor → SQL Editor → paste → Run). It creates:
- `app_stats` — a single-row counter that backs both the "Downloads" and
  "Active students" numbers on the landing page (they intentionally always
  show the same value). It's incremented via the `increment_downloads()`
  function whenever a visitor clicks a "Get Started" / CTA button.
- `feedback` — stores everything submitted through the feedback form at the
  bottom of the page.

Row Level Security policies are included so the public anon key can only
read `app_stats`, call `increment_downloads()`, and insert into `feedback`
— it cannot read other visitors' feedback.

## 3. What changed from the original landing page
- Removed the "Sign in" button from the header (replaced with a "Live
  Preview" link to `/demo`).
- Removed the "Loved by focused students" trust line (and its star rating /
  avatar row) from the hero.
- Added a stats section (Downloads / Active students, same number) directly
  above "Everything in one place", live from Supabase.
- Added a feedback form as the last section of the page, stored in Supabase.
- Added `/demo` — a fully interactive live preview of the actual StudySync
  app, ported from `studysync (1).zip`. It works standalone; if you also
  want its Jarvis AI chat to call real Gemini instead of its built-in
  fallback replies, set `GEMINI_API_KEY` in `.env.local`.
