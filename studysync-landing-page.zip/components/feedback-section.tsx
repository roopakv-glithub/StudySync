'use client'

import { useState, type FormEvent } from 'react'
import { Star, Loader2, CheckCircle2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { supabase } from '@/lib/supabase'

export function FeedbackSection() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')
  const [rating, setRating] = useState(5)
  const [hoverRating, setHoverRating] = useState(0)
  const [status, setStatus] = useState<'idle' | 'submitting' | 'sent' | 'error'>('idle')

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!name.trim() || !message.trim()) return

    setStatus('submitting')
    const { error } = await supabase.from('feedback').insert({
      name: name.trim(),
      email: email.trim() || null,
      message: message.trim(),
      rating,
    })

    if (error) {
      console.error('feedback insert failed:', error.message)
      setStatus('error')
      return
    }

    setStatus('sent')
    setName('')
    setEmail('')
    setMessage('')
    setRating(5)
  }

  if (status === 'sent') {
    return (
      <section id="feedback" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
        <div className="mx-auto flex max-w-lg flex-col items-center gap-3 rounded-3xl border border-border bg-card p-10 text-center">
          <CheckCircle2 className="size-10 text-primary" aria-hidden="true" />
          <h2 className="font-display text-2xl font-bold text-foreground">
            Thanks for the feedback!
          </h2>
          <p className="text-muted-foreground">
            We read every note — it directly shapes what we build next.
          </p>
        </div>
      </section>
    )
  }

  return (
    <section id="feedback" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
      <div className="mx-auto max-w-2xl text-center">
        <span className="text-sm font-semibold text-primary">We&apos;d love to hear from you</span>
        <h2 className="mt-3 text-balance font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          Share your feedback
        </h2>
        <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
          Tell us what&apos;s working, what&apos;s missing, and what would make StudySync
          even better.
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="mx-auto mt-10 max-w-xl space-y-5 rounded-3xl border border-border bg-card p-6 sm:p-8"
      >
        <div className="flex items-center justify-center gap-1">
          {Array.from({ length: 5 }).map((_, i) => {
            const value = i + 1
            const filled = value <= (hoverRating || rating)
            return (
              <button
                key={value}
                type="button"
                aria-label={`Rate ${value} out of 5`}
                onClick={() => setRating(value)}
                onMouseEnter={() => setHoverRating(value)}
                onMouseLeave={() => setHoverRating(0)}
                className="p-1"
              >
                <Star
                  className={`size-7 transition-colors ${
                    filled ? 'fill-primary text-primary' : 'text-border'
                  }`}
                  aria-hidden="true"
                />
              </button>
            )
          })}
        </div>

        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label htmlFor="feedback-name" className="text-sm font-medium text-foreground">
              Name
            </label>
            <input
              id="feedback-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus-visible:ring-3 focus-visible:ring-ring/50"
              placeholder="Your name"
            />
          </div>
          <div>
            <label htmlFor="feedback-email" className="text-sm font-medium text-foreground">
              Email <span className="text-muted-foreground">(optional)</span>
            </label>
            <input
              id="feedback-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus-visible:ring-3 focus-visible:ring-ring/50"
              placeholder="you@example.com"
            />
          </div>
        </div>

        <div>
          <label htmlFor="feedback-message" className="text-sm font-medium text-foreground">
            Your feedback
          </label>
          <textarea
            id="feedback-message"
            required
            rows={4}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="mt-1.5 w-full resize-none rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none focus-visible:ring-3 focus-visible:ring-ring/50"
            placeholder="What do you think of StudySync?"
          />
        </div>

        {status === 'error' && (
          <p className="text-sm text-destructive">
            Something went wrong sending your feedback. Please try again.
          </p>
        )}

        <Button
          type="submit"
          disabled={status === 'submitting'}
          className="w-full rounded-full font-semibold"
        >
          {status === 'submitting' ? (
            <>
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              Sending...
            </>
          ) : (
            'Send feedback'
          )}
        </Button>
      </form>
    </section>
  )
}
