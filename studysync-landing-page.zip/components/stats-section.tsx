'use client'

import { useEffect, useState } from 'react'
import { Download, Users } from 'lucide-react'
import { supabase } from '@/lib/supabase'

function formatCount(n: number) {
  return n.toLocaleString('en-US') + '+'
}

export function StatsSection() {
  // Both stats intentionally mirror the same underlying counter.
  const [count, setCount] = useState<number | null>(null)

  useEffect(() => {
    let isMounted = true

    async function loadCount() {
      const { data, error } = await supabase
        .from('app_stats')
        .select('count')
        .eq('id', 1)
        .single()

      if (!error && data && isMounted) {
        setCount(data.count)
      }
    }

    loadCount()

    // Keep the number live if it changes elsewhere (e.g. another visitor
    // clicking "Get Started" bumps public.app_stats via increment_downloads()).
    const channel = supabase
      .channel('app_stats_changes')
      .on(
        'postgres_changes' as any,
        { event: 'UPDATE', schema: 'public', table: 'app_stats', filter: 'id=eq.1' },
        (payload: any) => {
          if (isMounted) setCount(payload.new.count)
        },
      )
      .subscribe()

    return () => {
      isMounted = false
      supabase.removeChannel(channel)
    }
  }, [])

  const display = count === null ? '—' : formatCount(count)

  return (
    <section className="mx-auto max-w-6xl px-5 pt-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="flex items-center gap-4 rounded-2xl border border-border bg-card p-6">
          <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-accent text-primary">
            <Download className="size-6" aria-hidden="true" />
          </span>
          <div>
            <p className="font-display text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
              {display}
            </p>
            <p className="text-sm text-muted-foreground">Downloads</p>
          </div>
        </div>

        <div className="flex items-center gap-4 rounded-2xl border border-border bg-card p-6">
          <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-accent text-primary">
            <Users className="size-6" aria-hidden="true" />
          </span>
          <div>
            <p className="font-display text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
              {display}
            </p>
            <p className="text-sm text-muted-foreground">Active students</p>
          </div>
        </div>
      </div>
    </section>
  )
}
