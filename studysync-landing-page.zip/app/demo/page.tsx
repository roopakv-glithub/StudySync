import type { Metadata } from 'next'
import StudySyncApp from '@/components/demo/study-sync-app'

export const metadata: Metadata = {
  title: 'Live Preview — StudySync',
  description: 'Click through a fully interactive preview of the StudySync app.',
}

export default function DemoPage() {
  return <StudySyncApp />
}
