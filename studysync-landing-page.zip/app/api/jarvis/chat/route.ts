import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const { message, history } = await req.json()

  if (!message) {
    return NextResponse.json({ error: 'Message is required.' }, { status: 400 })
  }

  const apiKey = process.env.GEMINI_API_KEY
  if (!apiKey) {
    // No key configured — let the demo's built-in fallback responses handle it.
    return NextResponse.json(
      { error: 'GEMINI_API_KEY is not configured on the server.' },
      { status: 503 },
    )
  }

  try {
    const { GoogleGenAI } = await import('@google/genai')
    const ai = new GoogleGenAI({ apiKey })

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `You are Jarvis, an advanced academic co-pilot. Help the student optimize their study habits, draft study schedules, explain complex topics, and stay motivated. Be encouraging, professional, and precise. Here is the conversation history: ${JSON.stringify(
                history || [],
              )}. Student request: ${message}`,
            },
          ],
        },
      ],
      config: { temperature: 0.7 },
    })

    return NextResponse.json({ reply: response.text })
  } catch (error: any) {
    console.error('Gemini API Error:', error)
    return NextResponse.json({ error: 'Failed to reach Gemini.' }, { status: 500 })
  }
}
